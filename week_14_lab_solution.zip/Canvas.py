# ---------------------------------------------
# Basic Canvas module derived from Tkinter
# for drawing oval, lines, and text only
# Created by Sofiat Olaosebikan 07 Feb 2023
# ---------------------------------------------

import tkinter as tk

class getCanvas():
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("The Travelling Salesman Problem")
        # create the Canvas to draw on
        self.canvas = tk.Canvas(self.root, width="500", height="400")
        #print(type(self.canvas))

    def create_line(self, x1, y1, x2, y2, **kw):
        self.canvas.create_line(x1, y1, x2, y2, kw)      
    
    def create_oval(self, x1, y1, x2, y2):
        self.canvas.create_oval(x1, y1, x2, y2)
        
    def create_text(self, x, y, **kw):        
        self.canvas.create_text(x, y, kw)
        
    def display(self):
        self.canvas.pack()
        self.root.mainloop()
        
