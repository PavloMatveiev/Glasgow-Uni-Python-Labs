import random
from IPython.display import HTML
from ipycanvas import Canvas, hold_canvas
from IPython.display import display, clear_output
import time
import numpy as np 
class Lander(object):
    def __init__(self, fn):
        self.distance = 500.0
        self.velocity = -50.0
        self.fn = fn
        self.fuel = 150.0
        self.fuel_rate = 8.0
        self.gravity = 1.62
        self.fuel_density = 0.9
        self.module_mass = 1500
        self.engine_thrust = 18500
        self.oxygen_density = 1.14
        self.impact_velocity = 0
        self.oxygen = 150
        self.oxygen_rate = 1.5
        self.particles = np.random.normal(0, 1, (500, 6))
        self.stars = np.random.uniform(0, 1000, (80, 2))
        
        
        self.impacted = False
        self.dt = 0.1
        self.max_speed = 0
        self.max_fuel = self.fuel
        self.max_oxygen = self.oxygen
        self.max_distance = self.distance
        self.time = 0
        codes_1 = [
            "Valiant",
            "Burning",
            "Endless",
            "Fragrant",
            "Unbelievable",
            "Seventh",
            "Grand",
            "First",
            "Noble",
            "Dire",
            "Feeble",
            "Glorious",
            "Infernal",
            "Oblique",
            "Humperdink",
            "Tempramental",
            "Wonky",
            "Saturnine",
            "Invincible",
            "Unreliable",
            "Crunchy",
            "Furious",
            "Feeble",
            "Flimsy",
            "Green",
            "Foolish",
            "Fabulous",
            "Iridescent",
        ]
        codes_2 = [
            "Eagle",
            "Bird",
            "Thumper",
            "Crisis",
            "Gazelle",
            "Brick",
            "Soarer",
            "Solaris",
            "Lunar",
            "Crunching",
            "Falcon",
            "Seagull",
            "Bananas",
            "Friends",
            "Flop",
            "Beagle",
            "Bushbaby",
            "Velociraptor",
            "Reagan",
            "Brush",
            "Hawk",
            "Sparrow",
            "Gannet",
            "Reverend Marshall",
            "Owl",
            "Pigeon",
            "Bluetit",
        ]
        self.launch_name = "STS-%d" % (random.randint(30, 500))
        self.module_name = "\"%s %s\"" % (random.choice(codes_1), random.choice(codes_2))
        self.stopped = False
        self.thrust = 0

        

    def __repr__(self):
        out = []
        keys = [
            "velocity",
            "fuel",
            "fuel_rate",
            "gravity",
            "fuel_density",
            "module_mass",
            "engine_thrust",
            "oxygen",
            "oxygen_rate",
            "max_fuel",
            "max_oxygen",
            "max_distance",
            "distance",
            "launch_name",
            "module_name",
            "time",
        ]
        for k in keys:
            out.append("{0}={1}".format(k, self.__dict__[k]))
        return "\n".join(out)

    def draw(self, canvas):
        width = float(canvas.width)
        height = float(canvas.height)
        lander_w = 20
        lander_h = 25
        blast_h = 15

        canvas.clear()
        canvas.font = "16px sans-serif"

        
        # boom crash
        r = int(abs(self.impact_velocity) * 20)
        g = int(r / 1.5)
        b = int(r / 8)
        background = "#%02X%02X%02X" % (min(r, 255), min(g, 255), min(b, 255))
        canvas.fill_style= background
        self.impact_velocity *= 0.75
        #canvas.fill_style = "black"
        canvas.fill_rect(0, 0, width, height)
        landing = height * 0.9
        lheight = (1.0 - (self.distance / self.max_distance)) * landing
        canvas.fill_style="white"
        canvas.fill_rects((self.stars[:,0]+self.time).astype(np.int32), self.stars[:,1].astype(np.int32), 1)    
        # ground
        canvas.fill_style = "gray"
        canvas.fill_rect(0, landing, width, height)

        if self.impacted:
             # crater
            canvas.fill_style = background
            canvas.fill_circle(width // 2, lheight - lander_w*2 + min(abs(self.velocity), lander_w*2), lander_w * 2)   

        # particles 

        if not self.impacted:
            self.particles[:, 0] = width//2
            self.particles[:, 1] = lheight 
        else:
            self.particles[:,0:2] += self.particles[:,2:4] * 0.2
            self.particles[:, 2:4] += self.impact_velocity * self.particles[:,4:6] * 0.5
            self.particles[:, 3] = -np.abs(self.particles[:,3]) 
              
            canvas.fill_style = "#ffffff"# + "%02x"%(int(min(abs(self.impact_velocity*200), 255)))
            canvas.fill_rects(self.particles[:,0].astype(np.int32), self.particles[:,1].astype(np.int32), 2)   

           

       
        lander_pts = [
            [-lander_w // 2, -lander_h],
            [-lander_w, 0],
            [lander_w, 0],
            [lander_w // 2, -lander_h],
        ]

        lander_pts = [[x + width // 2, y + lheight] for x, y in lander_pts]
        # canvas.rectangle(width/2-lander_w, lheight-lander_h, width/2+lander_w,  lheight, fill="gray")
        canvas.fill_style = "#999999"
        canvas.fill_polygon(lander_pts)
        

        r = int(self.thrust * 1000)
        g = int(r / 1.5)
        b = int(r / 8)   
        flash_color =     "#%02X%02X%02X" % (min(r, 255), min(g, 255), min(b, 255)) 
        canvas.fill_style= flash_color
        if not self.impacted:
            canvas.fill_rect(
                width // 2 - lander_w,
                lheight,
                lander_w*2,
                blast_h,    
            )

            
        

        fuel_y = 30
        oxy_y = 60
        bar_x = 5
        bar_h = 8
        bar_w = 70
        speed_y = 100
        canvas.fill_style = "white"
        canvas.fill_rect(bar_x, fuel_y, bar_w, bar_h)
        canvas.fill_style = "red"
        canvas.fill_rect(
            bar_x,
            fuel_y,
            bar_w * self.fuel // self.max_fuel,
            bar_h,            
        )
        
        canvas.text_align = "left"
        canvas.fill_style = "gray"
        canvas.fill_text("Fuel", bar_x, fuel_y -5)

        canvas.fill_style = "white"
        canvas.fill_rect(bar_x, oxy_y, bar_w, bar_h)
        canvas.fill_style = "blue"
        canvas.fill_rect(
            bar_x,
            oxy_y,
            bar_w * self.oxygen // self.max_oxygen,
            bar_h,            
        )
        canvas.fill_style="gray"
        canvas.fill_text("Oxygen", bar_x, oxy_y - 5)
        canvas.fill_style="green"
        canvas.text_align = "center"
        
        canvas.fill_text(self.launch_name, width / 2, 20)
        canvas.font = "24px sans-serif"
        canvas.fill_text(self.module_name, width / 2, 50)
        canvas.font = "16px sans-serif"
        canvas.text_align = "left"
        canvas.fill_style = "white"
        canvas.fill_text(
            "Velocity:  % 4.2f m/s" % self.velocity,
            bar_x,
            speed_y,            
        )
        canvas.fill_style = "red"
        canvas.fill_text(
            "Altitude: % 4.1f m" % self.distance,
            bar_x,
            speed_y + 20,
        )        
            
        danger = abs(self.velocity * 5) - self.distance
        if self.impacted:
            v = abs(self.velocity)
            if v > 10:
                crew = "Liquid"
            elif v > 5:
                crew = "Unresponsive"
            elif v > 1:
                crew = "Injured"
            else:
                crew = "Relaxed"
        else:
            if danger < 0 and abs(self.velocity<10):
                crew = "Happy"            
            elif danger < 0:
                crew = "Unsettled"
            elif danger < 20:
                crew = "Concerned"
            elif danger < 40:
                crew = "Worried"
            elif danger < 80:
                crew = "Frightened"
            elif danger < 160:
                crew = "Terrified"
            else:
                crew = "AAAAAAAAA!"            

        if self.distance > 600:
            crew = "Feeling lonely"
        if self.distance > 800:
            crew = "Very worried"
        if self.distance > 1000:
            crew = "Adrift"

        if self.oxygen < 1:
            crew = "Dead"        
        elif self.oxygen < 5:
            crew = "Unconscious"
        elif self.oxygen < 20:
            crew = "Hypoxic"
        elif self.oxygen < 50:
            crew = "Breathless"
        
        
        canvas.fill_style="white"
        canvas.fill_text(f"Crew state: {crew}", bar_x, speed_y+50)

        

    def update(self, dt):

        if self.fn(self.distance, -self.velocity):
            thrust = 1
        else:
            thrust = 0
        if self.fuel <= 0:
            thrust = 0

        self.thrust = self.thrust * 0.96 + 0.04 * thrust

        self.fuel -= thrust * self.fuel_rate * self.dt
        self.mass = (
            self.fuel_density * self.fuel
            + self.module_mass
            + self.oxygen_density * self.oxygen
        )
        acc = (thrust * self.engine_thrust) / self.mass - self.gravity
        self.oxygen -= self.dt * self.oxygen_rate
        self.velocity += acc * self.dt
        self.distance += self.velocity * self.dt
        self.time += self.dt
        print = display
        if self.oxygen < 0:
            print("Oxygen has run out. The crew have died :(")
            return True

        if self.distance  < 0:
            self.impacted = True
            self.impact_velocity = self.velocity
            if abs(self.velocity) > 50.0:
                print(
                    "Impact velocity was %.2f m/s: module made an enormous crater!"
                    % self.velocity
                )
                return True
            elif abs(self.velocity) > 15.0:
                print(
                    "Impact velocity was %.2f m/s: module utterly destroyed!"
                    % self.velocity
                )
                return True
            elif abs(self.velocity) > 4.0:
                print("Impact velocity was %.2f m/s: module destroyed!" % self.velocity)
                return True
            elif abs(self.velocity) > 1:
                print("Impact velocity was %.2f m/s: module damaged!" % self.velocity)
                return True
            else:
                print(
                    "Impact velocity was %.2f m/s: module survived unharmed!"
                    % self.velocity
                )
                return True

        if self.distance > 1000 and self.velocity > 0:
            print("Module drifted off into space at %.2f m/s" % self.velocity)
            return True

        if abs(self.velocity) > self.max_speed:
            self.max_speed = abs(self.velocity)

        return False


def simulate(fn):
    clear_output()    
    canvas = Canvas(width=900, height=500)    
    display(canvas)
    lander = Lander(fn)
    msg = False    

    
    while not msg:
        with hold_canvas(canvas):    
            canvas.clear()
            lander.draw(canvas)
            canvas.sleep(20)
            msg = lander.update(0.01)            
    # post-landing crunch
    for i in range(80):
        with hold_canvas(canvas):    
            canvas.clear()
            lander.draw(canvas)
            canvas.sleep(20)
                
        
    return lander


def test_fn(x, y):
    return True


if __name__ == "__main__":
    simulate(test_fn)

